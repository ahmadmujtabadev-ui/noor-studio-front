import { api } from './client';
import type { Character, VisualDNA, ModestyRules } from './types';

export interface CreateCharacterInput {
  universeId: string;
  name: string;
  role: Character['role'];
  ageRange?: string;
  traits?: string[];
  speakingStyle?: string;
  visualDNA?: Partial<VisualDNA>;
  modestyRules?: Partial<ModestyRules>;
}

export interface UpdateCharacterInput extends Partial<CreateCharacterInput> {
  imageUrl?: string;
  poseSheetUrl?: string;
  status?: Character['status'];
}

export const charactersApi = {
  list: (params?: { universeId?: string }) =>
    api.get<Character[]>('/api/characters', { params }),

  get: (id: string) =>
    api.get<Character>(`/api/characters/${id}`),

  create: (data: CreateCharacterInput) =>
    api.post<Character>('/api/characters', data),

  update: (id: string, data: UpdateCharacterInput) =>
    api.put<Character>(`/api/characters/${id}`, data),

  delete: (id: string) =>
    api.delete<{ message: string }>(`/api/characters/${id}`),

  generatePortrait: (id: string, data?: { style?: string; customPrompt?: string }) =>
    api.post<{ imageUrl: string; provider: string }>(`/api/characters/${id}/generate-portrait`, data),

  generatePoseSheet: (id: string) =>
    api.post<{ poseSheetUrl: string; provider: string }>(`/api/characters/${id}/generate-pose-sheet`),

  approve: (id: string, imageUrl?: string) =>
    api.put<Character>(`/api/characters/${id}`, {
      status: 'approved',
      ...(imageUrl ? { imageUrl } : {}),
    }),
};
