import { api } from './client';
import type { CreditPackage, CreditTransaction, CreditBalance } from './types';

export const paymentsApi = {
  getPackages: () =>
    api.get<{ packages: CreditPackage[] }>('/api/payments/packages'),

  getBalance: () =>
    api.get<CreditBalance>('/api/payments/balance'),

  getTransactions: (params?: { limit?: number; offset?: number }) =>
    api.get<{ transactions: CreditTransaction[]; total: number }>('/api/payments/transactions', { params }),

  createCheckout: (data: { packageId: string; successUrl?: string; cancelUrl?: string }) =>
    api.post<{ url: string }>('/api/payments/create-checkout', data),

  createSubscription: (data: { priceId: string }) =>
    api.post<{ url: string }>('/api/payments/create-subscription', data),

  cancelSubscription: () =>
    api.post<{ message: string }>('/api/payments/cancel-subscription'),
};
