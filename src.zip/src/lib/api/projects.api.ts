import { api } from './client';
import type { Project, ProjectArtifacts, LayoutArtifact } from './types';

export interface CreateProjectInput {
  universeId?: string;
  characterIds?: string[];
  title: string;
  ageRange?: string;
  chapterCount?: number;
  template?: Project['template'];
  learningObjective?: string;
  authorName?: string;
  trimSize?: string;
}

export interface UpdateProjectInput extends Partial<CreateProjectInput> {
  status?: Project['status'];
  currentStage?: Project['currentStage'];
  artifacts?: Partial<ProjectArtifacts>;
}

export const projectsApi = {
  list: () =>
    api.get<Project[]>('/api/projects'),

  get: (id: string) =>
    api.get<Project>(`/api/projects/${id}`),

  create: (data: CreateProjectInput) =>
    api.post<Project>('/api/projects', data),

  update: (id: string, data: UpdateProjectInput) =>
    api.put<{ message: string; updatedAt: string }>(`/api/projects/${id}`, data),

  delete: (id: string) =>
    api.delete<{ message: string }>(`/api/projects/${id}`),

  generateLayout: (id: string) =>
    api.post<{ layout: LayoutArtifact }>(`/api/projects/${id}/layout`),

  publish: (id: string) =>
    api.post<{ shareUrl: string; shareToken: string }>(`/api/projects/${id}/publish`),
};
