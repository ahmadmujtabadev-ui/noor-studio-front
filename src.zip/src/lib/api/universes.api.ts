import { api } from './client';
import type { Universe } from './types';

export interface CreateUniverseInput {
  name: string;
  artStyle: Universe['artStyle'];
  seriesBible?: string;
  colorPalette?: string[];
  islamicRules?: {
    hijabAlways?: boolean;
    noMusic?: boolean;
    customRules?: string;
  };
}

export const universesApi = {
  list: () =>
    api.get<Universe[]>('/api/universes'),

  get: (id: string) =>
    api.get<Universe>(`/api/universes/${id}`),

  create: (data: CreateUniverseInput) =>
    api.post<Universe>('/api/universes', data),

  update: (id: string, data: Partial<CreateUniverseInput>) =>
    api.put<Universe>(`/api/universes/${id}`, data),

  delete: (id: string) =>
    api.delete<{ message: string }>(`/api/universes/${id}`),
};
