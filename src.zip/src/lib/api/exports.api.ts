import { api, tokenStorage } from './client';
import type { Export } from './types';

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001';

export const exportsApi = {
  list: (projectId: string) =>
    api.get<Export[]>(`/api/exports/${projectId}`),

  delete: (id: string) =>
    api.delete<{ message: string }>(`/api/exports/${id}`),

  /**
   * Generate and download PDF for a project.
   * Returns an object URL pointing to the PDF blob.
   */
  downloadPdf: async (projectId: string): Promise<string> => {
    const token = tokenStorage.get();
    const res = await fetch(`${BASE_URL}/api/exports`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({ projectId }),
    });

    if (!res.ok) {
      let msg = 'Export failed';
      try {
        const err = await res.json();
        msg = err?.error?.message || msg;
      } catch { /* ignore */ }
      throw new Error(msg);
    }

    const blob = await res.blob();
    return URL.createObjectURL(blob);
  },
};
