// ─── Auth ─────────────────────────────────────────────────────────────────────

export interface User {
  _id: string;
  name: string;
  email: string;
  credits: number;
  plan: 'free' | 'starter' | 'pro' | 'studio';
  stripeCustomerId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuthResponse {
  token: string;
  user: User;
}

// ─── Universe ─────────────────────────────────────────────────────────────────

export interface IslamicRules {
  hijabAlways: boolean;
  noMusic: boolean;
  customRules?: string;
}

export interface Universe {
  _id: string;
  userId: string;
  name: string;
  artStyle: 'pixar-3d' | 'watercolor' | 'flat-illustration' | 'manga' | 'pencil-sketch' | 'oil-painting';
  seriesBible?: string;
  colorPalette: string[];
  islamicRules: IslamicRules;
  characterCount?: number;
  bookCount?: number;
  createdAt: string;
  updatedAt: string;
}

// ─── Character ────────────────────────────────────────────────────────────────

export interface VisualDNA {
  style?: string;
  gender?: string;
  skinTone?: string;
  eyeColor?: string;
  faceShape?: string;
  hairOrHijab?: string;
  outfitRules?: string;
  accessories?: string;
  paletteNotes?: string;
}

export interface ModestyRules {
  hijabAlways?: boolean;
  longSleeves?: boolean;
  looseClothing?: boolean;
}

export interface Character {
  _id: string;
  userId: string;
  universeId: string;
  name: string;
  role: 'protagonist' | 'supporting' | 'antagonist' | 'mentor' | 'background';
  ageRange?: string;
  traits: string[];
  speakingStyle?: string;
  visualDNA: VisualDNA;
  modestyRules: ModestyRules;
  imageUrl?: string;
  poseSheetUrl?: string;
  status: 'draft' | 'generated' | 'approved';
  createdAt: string;
  updatedAt: string;
}

// ─── Knowledge Base ───────────────────────────────────────────────────────────

export interface Dua {
  arabic?: string;
  transliteration: string;
  meaning: string;
  context?: string;
}

export interface VocabularyEntry {
  word: string;
  definition: string;
  ageGroup?: string;
}

export interface KnowledgeBase {
  _id: string;
  userId: string;
  universeId: string;
  name: string;
  islamicValues: string[];
  duas: Dua[];
  vocabulary: VocabularyEntry[];
  illustrationRules: string[];
  avoidTopics: string[];
  customRules?: string;
  createdAt: string;
  updatedAt: string;
}

// ─── Project ──────────────────────────────────────────────────────────────────

export interface IllustrationVariant {
  variantIndex: number;
  imageUrl: string;
  prompt?: string;
  seed?: number;
  selected: boolean;
}

export interface IllustrationArtifact {
  chapterNumber: number;
  variants: IllustrationVariant[];
  selectedVariantIndex: number;
}

export interface ChapterArtifact {
  chapterNumber: number;
  chapterTitle: string;
  text: string;
  vocabularyNotes?: string[];
  islamicAdabChecks?: string[];
}

export interface HumanizedArtifact {
  chapterNumber: number;
  chapterTitle: string;
  text: string;
  changesMade?: string[];
}

export interface OutlineChapter {
  title: string;
  goal: string;
  keyScene: string;
  duaHint: string;
}

export interface OutlineArtifact {
  bookTitle: string;
  moral: string;
  chapters: OutlineChapter[];
}

export interface CoverArtifact {
  frontUrl?: string;
  backUrl?: string;
  prompt?: string;
}

export interface SpreadContent {
  imageUrl?: string;
  title?: string;
  author?: string;
  chapterTitle?: string;
  text?: string;
  chapterNumber?: number;
  vocabulary?: VocabularyEntry[];
}

export interface Spread {
  page: number;
  type: 'cover' | 'title-page' | 'illustration' | 'text' | 'glossary' | 'back-cover';
  content: SpreadContent;
}

export interface LayoutArtifact {
  spreads: Spread[];
  pageCount: number;
  trimSize?: string;
}

export interface ProjectArtifacts {
  outline?: OutlineArtifact;
  chapters?: ChapterArtifact[];
  humanized?: HumanizedArtifact[];
  illustrations?: IllustrationArtifact[];
  cover?: CoverArtifact;
  layout?: LayoutArtifact;
}

export type ProjectStage = 'outline' | 'chapters' | 'humanized' | 'illustrations' | 'cover' | 'layout' | 'export';
export type ProjectStatus = 'draft' | 'in-progress' | 'review' | 'complete';

export interface Project {
  _id: string;
  userId: string;
  universeId?: string | Universe;
  characterIds: string[] | Character[];
  title: string;
  ageRange?: string;
  chapterCount: number;
  template: 'moral' | 'adventure' | 'educational' | 'bedtime';
  learningObjective?: string;
  authorName?: string;
  trimSize?: string;
  status: ProjectStatus;
  currentStage?: ProjectStage;
  artifacts: ProjectArtifacts;
  shareToken?: string;
  publishedAt?: string;
  createdAt: string;
  updatedAt: string;
}

// ─── AI ───────────────────────────────────────────────────────────────────────

export type TextStage = 'outline' | 'chapter' | 'humanize';
export type ImageTask = 'illustration' | 'cover' | 'portrait' | 'pose-sheet';

export interface TextGenerateRequest {
  stage: TextStage;
  projectId: string;
  chapterIndex?: number;
}

export interface TextGenerateResponse {
  result: OutlineArtifact | ChapterArtifact | HumanizedArtifact | Record<string, unknown>;
  usage: { inputTokens: number; outputTokens: number };
  provider: string;
  creditsCharged: number;
}

export interface ImageGenerateRequest {
  task: ImageTask;
  projectId: string;
  chapterIndex?: number;
  style?: string;
  customPrompt?: string;
  seed?: number;
}

export interface ImageGenerateResponse {
  imageUrl: string;
  provider: string;
  traceId: string;
  providerMeta?: Record<string, unknown>;
}

export interface AIProviderStatus {
  textProvider: string;
  imageProvider: string;
  claudeConfigured: boolean;
  bflConfigured: boolean;
  replicateConfigured: boolean;
  geminiConfigured: boolean;
  nanobananaConfigured: boolean;
  openaiDisabled: boolean;
  routing: Record<string, string>;
}

// ─── Payments ─────────────────────────────────────────────────────────────────

export interface CreditPackage {
  id: string;
  name: string;
  credits: number;
  price: number;
  currency: string;
  popular?: boolean;
}

export interface CreditTransaction {
  _id: string;
  userId: string;
  amount: number;
  type: 'credit' | 'debit';
  description: string;
  refType?: string;
  refId?: string;
  createdAt: string;
}

export interface CreditBalance {
  credits: number;
  plan: string;
}

// ─── Export ───────────────────────────────────────────────────────────────────

export interface Export {
  _id: string;
  projectId: string;
  userId: string;
  pdfUrl?: string;
  epubUrl?: string;
  pageCount?: number;
  status: 'pending' | 'processing' | 'ready' | 'failed';
  expiresAt?: string;
  createdAt: string;
}

// ─── API Error ────────────────────────────────────────────────────────────────

export interface ApiError {
  code: string;
  message: string;
  details?: unknown;
}

export class NoorApiError extends Error {
  code: string;
  statusCode: number;
  details?: unknown;

  constructor(message: string, code: string, statusCode: number, details?: unknown) {
    super(message);
    this.name = 'NoorApiError';
    this.code = code;
    this.statusCode = statusCode;
    this.details = details;
  }
}
