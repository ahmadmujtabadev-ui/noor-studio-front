import { api } from './client';
import type {
  TextGenerateRequest,
  TextGenerateResponse,
  ImageGenerateRequest,
  ImageGenerateResponse,
  AIProviderStatus,
} from './types';

export const aiApi = {
  // ── Text generation (outline / chapter / humanize) ────────────────────────
  generateText: (data: TextGenerateRequest) =>
    api.post<TextGenerateResponse>('/api/ai/generate', data),

  // Convenience wrappers
  generateOutline: (projectId: string) =>
    api.post<TextGenerateResponse>('/api/ai/generate', { stage: 'outline', projectId }),

  generateChapter: (projectId: string, chapterIndex: number) =>
    api.post<TextGenerateResponse>('/api/ai/generate', { stage: 'chapter', projectId, chapterIndex }),

  humanizeChapter: (projectId: string, chapterIndex: number) =>
    api.post<TextGenerateResponse>('/api/ai/generate', { stage: 'humanize', projectId, chapterIndex }),

  // ── Image generation ──────────────────────────────────────────────────────
  generateImage: (data: ImageGenerateRequest) =>
    api.post<ImageGenerateResponse>('/api/ai/image/generate', data),

  generateIllustration: (projectId: string, chapterIndex: number, style?: string) =>
    api.post<ImageGenerateResponse>('/api/ai/image/generate', {
      task: 'illustration',
      projectId,
      chapterIndex,
      style: style || 'pixar-3d',
    }),

  generateCover: (projectId: string, style?: string) =>
    api.post<ImageGenerateResponse>('/api/ai/image/generate', {
      task: 'cover',
      projectId,
      style: style || 'pixar-3d',
    }),

  // ── Status ────────────────────────────────────────────────────────────────
  getStatus: () =>
    api.get<AIProviderStatus>('/api/ai/status'),
};
