import { useQuery, useMutation } from '@tanstack/react-query';
import { paymentsApi } from '@/lib/api/payments.api';

export function useCreditPackages() {
  return useQuery({
    queryKey: ['payments', 'packages'],
    queryFn: paymentsApi.getPackages,
    staleTime: 10 * 60 * 1000,
  });
}

export function useCreditBalance() {
  return useQuery({
    queryKey: ['payments', 'balance'],
    queryFn: paymentsApi.getBalance,
    staleTime: 60 * 1000,
  });
}

export function useTransactions(params?: { limit?: number; offset?: number }) {
  return useQuery({
    queryKey: ['payments', 'transactions', params],
    queryFn: () => paymentsApi.getTransactions(params),
    staleTime: 60 * 1000,
  });
}

export function useCreateCheckout() {
  return useMutation({
    mutationFn: paymentsApi.createCheckout,
    onSuccess: ({ url }) => {
      window.location.href = url;
    },
  });
}

export function useCancelSubscription() {
  return useMutation({
    mutationFn: paymentsApi.cancelSubscription,
  });
}
