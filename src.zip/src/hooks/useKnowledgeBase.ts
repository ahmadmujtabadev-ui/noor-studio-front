import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { knowledgeBasesApi, type CreateKnowledgeBaseInput } from '@/lib/api/knowledgeBases.api';

export const KB_KEY = ['knowledge-bases'] as const;
export const kbKey = (id: string) => ['knowledge-bases', id] as const;
export const kbByUniverse = (universeId: string) => ['knowledge-bases', { universeId }] as const;

export function useKnowledgeBases(universeId?: string) {
  return useQuery({
    queryKey: universeId ? kbByUniverse(universeId) : KB_KEY,
    queryFn: () => knowledgeBasesApi.list(universeId ? { universeId } : undefined),
    staleTime: 2 * 60 * 1000,
  });
}

export function useKnowledgeBase(id: string | undefined) {
  return useQuery({
    queryKey: kbKey(id!),
    queryFn: () => knowledgeBasesApi.get(id!),
    enabled: !!id,
    staleTime: 2 * 60 * 1000,
  });
}

export function useKnowledgeBaseByUniverse(universeId: string | undefined) {
  return useQuery({
    queryKey: kbByUniverse(universeId!),
    queryFn: () => knowledgeBasesApi.getByUniverse(universeId!),
    enabled: !!universeId,
    staleTime: 2 * 60 * 1000,
  });
}

export function useCreateKnowledgeBase() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: CreateKnowledgeBaseInput) => knowledgeBasesApi.create(data),
    onSuccess: (kb) => {
      qc.invalidateQueries({ queryKey: KB_KEY });
      if (kb.universeId) qc.invalidateQueries({ queryKey: kbByUniverse(kb.universeId) });
    },
  });
}

export function useUpdateKnowledgeBase(id: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: Partial<CreateKnowledgeBaseInput>) => knowledgeBasesApi.update(id, data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: KB_KEY });
      qc.invalidateQueries({ queryKey: kbKey(id) });
    },
  });
}

export function useDeleteKnowledgeBase() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => knowledgeBasesApi.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: KB_KEY }),
  });
}
