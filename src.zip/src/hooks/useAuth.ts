import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '@/lib/store/authStore';
import { authApi } from '@/lib/api/auth.api';
import { NoorApiError } from '@/lib/api/types';

export function useAuth() {
  return useAuthStore();
}

export function useLoginMutation() {
  const login = useAuthStore((s) => s.login);
  const navigate = useNavigate();

  return useMutation({
    mutationFn: ({ email, password }: { email: string; password: string }) =>
      login(email, password),
    onSuccess: () => navigate('/app/dashboard'),
  });
}

export function useRegisterMutation() {
  const register = useAuthStore((s) => s.register);
  const navigate = useNavigate();

  return useMutation({
    mutationFn: ({ name, email, password }: { name: string; email: string; password: string }) =>
      register(name, email, password),
    onSuccess: () => navigate('/app/dashboard'),
  });
}

export function useLogout() {
  const logout = useAuthStore((s) => s.logout);
  const navigate = useNavigate();
  const qc = useQueryClient();

  return () => {
    logout();
    qc.clear();
    navigate('/auth');
  };
}

export function useChangePasswordMutation() {
  return useMutation({
    mutationFn: (data: { currentPassword: string; newPassword: string }) =>
      authApi.changePassword(data),
  });
}

export function useRefreshUser() {
  const refreshUser = useAuthStore((s) => s.refreshUser);
  const token = useAuthStore((s) => s.token);

  return useQuery({
    queryKey: ['auth', 'me'],
    queryFn: refreshUser,
    enabled: !!token,
    staleTime: 5 * 60 * 1000, // 5 min
    retry: false,
  });
}
