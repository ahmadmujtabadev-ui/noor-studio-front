import { useQuery, useMutation } from '@tanstack/react-query';
import { exportsApi } from '@/lib/api/exports.api';
import { useAuthStore } from '@/lib/store/authStore';

export function useExports(projectId: string | undefined) {
  return useQuery({
    queryKey: ['exports', projectId],
    queryFn: () => exportsApi.list(projectId!),
    enabled: !!projectId,
    staleTime: 30 * 1000,
  });
}

export function useDownloadPdf(projectId: string) {
  const refreshUser = useAuthStore((s) => s.refreshUser);

  return useMutation({
    mutationFn: () => exportsApi.downloadPdf(projectId),
    onSuccess: (objectUrl) => {
      // Trigger browser download
      const a = document.createElement('a');
      a.href = objectUrl;
      a.download = `noorstudio-book.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(objectUrl);
      refreshUser(); // credits were spent
    },
  });
}
